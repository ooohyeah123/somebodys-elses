package com.cg.dto;

public class ARS {
	
	private int airId;
	private String name;
	private String gender;
	private String flight;
	private String email;
	private String phone;
	
	public int getAirId() {
		return airId;
	}
	public void setAirId(int airId) {
		this.airId = airId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getFlight() {
		return flight;
	}
	public void setFlight(String flight) {
		this.flight = flight;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
}
