package com.cg.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.ARS;
import com.cg.service.FlightsServiceimpl;
import com.cg.service.IFlightsService;

@WebServlet("/flights")
public class ARSystem extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ARSystem() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String action = request.getParameter("action");
		
		IFlightsService service = new FlightsServiceimpl();
		
		switch(action){
		case "add":
			
			ARS air = new ARS();
			air.getName(request.)
		}
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	
		doGet(request, response);
		
	}

}
