package com.cg.service;

import java.util.List;

import com.cg.dto.ARS;

public interface IFlightsService
{
	void add(ARS ars);
	
	List<ARS> getAll();
	
	void update(ARS ars);
	
	ARS search(int airId);
	
}
