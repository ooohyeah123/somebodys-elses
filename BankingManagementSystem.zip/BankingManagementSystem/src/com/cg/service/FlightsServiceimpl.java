package com.cg.service;

import java.util.List;

import com.cg.dto.ARS;

public class FlightsServiceimpl implements IFlightsService 
{

	
	
	@Override
	public void add(ARS ars) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<ARS> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(ARS ars) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ARS search(int airId) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
