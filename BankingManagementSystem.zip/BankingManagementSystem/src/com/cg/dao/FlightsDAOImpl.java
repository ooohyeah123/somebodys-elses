package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import javax.naming.NamingException;

import com.cg.dto.ARS;
import com.cg.servlet.ARSException;
import com.cg.util.DbUtil;

public class FlightsDAOImpl implements IFlightsDAO
{
	private static final String INSERT_QUERY="Insert into ars(arsId,name,gender,"
			+ "flight,email,phone)values(ars_seq.nextval,?,?,?,?,?)";

	private static final String GET_ALL_QUERY ="select arsId,name,gender,"
			+ "flight,email,phone from ars";

	private static final String UPDATE_QUERY
	= "update ars set name=?, gender=?, "
			+ "  flight=?, email=?, phone=? where empid=?";

	private static final String SELECT_QUERY=
		"select arsId,name,flight,email,phone from emp2 where airId=?";

	@Override
	public int add(ARS ars) throws ARSException {
		
		Connection con;
		try {
			con = DbUtil.obtainConnection();
			PreparedStatement ps = con.prepareStatement(INSERT_QUERY);
			ps.setString(1,ars.getName());
			ps.setString(2, ars.getGender());
			ps.setString(3,ars.getFlight());
			ps.setString(5, ars.getEmail());
			ps.setString(4,ars.getPhone());
			
			ps.executeUpdate();
			
			int id =0;
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select ars_seq.nextval from dual");
			if(rs.next())
			{				
				id = rs.getInt(1);
				System.out.println("SEQ value "+id);
			}
			
			con.close();
			return id;	
		}
	catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ARSException("Unable to show, " +e.getMessage());
		}
	//	return id;	
}	
	

	@Override
	public List<ARS> getAll() {
		
		return null;
	}

	@Override
	public void update(ARS ars) {
		
		
	}

	@Override
	public ARS search(int airId) {
		
		return null;
	}

}
