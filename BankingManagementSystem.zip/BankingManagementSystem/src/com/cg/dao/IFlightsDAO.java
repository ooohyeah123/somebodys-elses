package com.cg.dao;

import java.util.List;

import com.cg.dto.ARS;
import com.cg.servlet.ARSException;

public interface IFlightsDAO
{
int add(ARS ars) throws ARSException;
	
	List<ARS> getAll();
	
	void update(ARS ars);
	
	ARS search(int airId);
}
